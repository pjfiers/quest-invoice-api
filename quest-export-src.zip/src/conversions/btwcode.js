let convert = function (input) {
    switch (input) {
        case 0.21:
            return 5
        default:
            return 0
    }
}

export default convert