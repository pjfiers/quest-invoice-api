let convert = function (input) {
    switch (input) {
        case 0.21:
            return 21
        default:
            return 0
    }
}

export default convert